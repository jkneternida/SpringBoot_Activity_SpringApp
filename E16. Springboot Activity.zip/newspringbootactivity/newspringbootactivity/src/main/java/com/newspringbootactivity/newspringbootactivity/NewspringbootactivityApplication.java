package com.newspringbootactivity.newspringbootactivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewspringbootactivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewspringbootactivityApplication.class, args);


	}

}
